﻿// See https://aka.ms/new-console-template for more information
var Tervehtijä = new Tervehtijä();
Console.WriteLine(Tervehtijä.HaeTervehdys());
Tervehtijä.AsetaTervehdys("Heipä hei");
Tervehtijä.Tervehdi(); 
Tervehtijä.Tervehdi(Console.ReadLine());

class Tervehtijä
{
    String tervehdys = "Hei hei";

    public void AsetaTervehdys(string uusiTervehdys)
    {
        this.tervehdys = uusiTervehdys;
    }

    public void Tervehdi()
    {
        Console.WriteLine(tervehdys);
    }

    public void Tervehdi(string omaTervehdys)
    {
        Console.WriteLine(omaTervehdys);
    }

    public string HaeTervehdys()
    {
        return tervehdys;
    }
}