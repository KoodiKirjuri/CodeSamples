-- Tehtävä 1. Hae kaikki kaupungit, ja niiden maat. Tulosta vain yksi kolumni, jossa lukee "Sijainti", jonka riveillä lukee kaupungin nimi ja maa, eroteltuna pilkulla.
SELECT concat(city, ", ", country.country) AS sijainti FROM sakila.city INNER JOIN sakila.country ON(city.country_id = country.country_id);
-- Tehtävä 2. Palauta tuloksiin kaikki maat ja niiden kaupunkien lukumäärä. Järjestä suurimmasta pienimpään. Palauta vain ylimmät 30 tulosta.
SELECT country, COUNT(city.city) AS kaupungit FROM sakila.country INNER JOIN sakila.city ON(city.country_id = country.country_id) GROUP BY country ORDER BY kaupungit DESC LIMIT 30;
-- Tehtävä 3. Hae kaikki kaupungit, ja palauta niiden osoitteiden lukumäärä. Kerro myös, missä maassa kaupunki sijaitsee.
SELECT city, COUNT(address.address) AS osoitteidenMaara, country.country AS Maa FROM sakila.city INNER JOIN sakila.address INNER JOIN sakila.country ON(address.city_id = city.city_id AND city.country_id = country.country_id) GROUP BY city, Maa;
-- Tehtävä 4. Hae kaikki asiakkaat ja heidän osoitteensa, kaupunkinsa ja maansa. 
SELECT CONCAT(first_name, " ", last_name ) AS asiakas, address.address AS Osoite, city.city AS Kaupunki, country.country AS Maa FROM sakila.customer INNER JOIN sakila.address INNER JOIN sakila.city INNER JOIN sakila.country ON(customer.address_id = address.address_id AND address.city_id = city.city_id AND city.country_id = country.country_id) ORDER BY asiakas ASC;
-- Tehtävä 5. Hae top 10 eniten maksavaa asiakasta.
SELECT CONCAT(first_name, " ", last_name) AS Asiakas, SUM(amount) AS Asiakas_Kayttanyt_Rahaa FROM sakila.payment INNER JOIN sakila.customer ON(customer.customer_id = payment.customer_id) GROUP BY asiakas ORDER BY Asiakas_Kayttanyt_Rahaa DESC LIMIT 10;