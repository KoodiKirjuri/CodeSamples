-- 1. Hae tietokannasta sen elokuvan tiedot, jonka tunniste on 351.
SELECT * FROM sakila.film WHERE film_id = 351;
-- 2. Hae tietokannasta elokuvan tunniste, nimi, julkaisuvuosi, pituus ja luokitus, jonka tunniste on 633.
SELECT film_id, title, release_year, length, rating FROM sakila.film WHERE film_id = 633;
-- 3. Tee edellinen haku uudelleen mutta nimeä uudelleen haettujen tulosten sarakkeiden nimet suomeksi englannin sijaan siten, että tuloksessa lukee elokuvan tunniste, elokuvan nimi, julkaisuvuosi, pituus, luokitus.
SELECT film_id AS "elokuvan tunniste", title AS "elokuvan nimi", release_year AS julkaisuvuosi, length AS pituus, rating AS luokitus FROM sakila.film WHERE film_id = 633;
-- 4. Hae elokuvat, joiden pituus on yli 60 minuuttia. Näytä vain ensimmäiset 10 tulosta.
SELECT * FROM sakila.film WHERE length < 60 limit 10;
-- 5. Tee edellinen haku uudelleen mutta tarkenna hakuehtoa vielä siten, että etsit vain PG-13 luokituksen saaneita elokuvia.
SELECT * FROM sakila.film WHERE length > 60 AND rating = "PG-13" limit 10;
-- 6. Hae 15 elokuvaa järjestettynä niiden keston mukaan pisimmästä lyhyimpään.
SELECT * FROM sakila.film ORDER BY length DESC LIMIT 15;
-- 7. Hae 10 elokuvaa järjestettynä keston mukaisesti pisimmästä lyhyimpään, jotka kuuluvat PG-13 tai R -luokitukseen.
SELECT * FROM sakila.film WHERE rating = "PG-13" OR rating = "R" ORDER BY length DESC LIMIT 10;
-- 8. Tee edellinen haku uudestaan mutta aseta hakuehdoiksi luokitukset G ja NC-17. Toteuta hakuehto käyttäen IN operaattoria.
SELECT * FROM sakila.film WHERE rating IN ("G", "NC-17") ORDER BY length DESC LIMIT 10;
-- 9. Hae lista kaikista elokuvista, joiden kesto on välillä 40 - 80 minuuttia. Järjestä pituuden mukaan pisimmästä lyhyimpään. (yhteensä tuloksia tulisi olla 253 kpl)
SELECT * FROM sakila.film WHERE length >= 40 AND length <= 80 ORDER BY length DESC;
-- 10. Tee edellinen haku uudelleen mutta aseta hakuehdoksi 30-60 minuuttia. Toteuta hakuehto käyttäen BETWEEN operaattoria. (yhteensä tuloksia tulisi olla 104 kpl)
SELECT * FROM sakila.film WHERE length BETWEEN 30 AND 60 ORDER BY length DESC;
-- 11. Mikä on kaikkien elokuvien keskimääräinen kesto? Entä lyhimmän elokuvan kesto? Entä pisimmän elokuvan kesto?
SELECT avg(length), min(length), max(length) FROM sakila.film;
-- 12. Hae uudelleen elokuvien keskimääräinen kesto mutta pyöristä luku kokonaisluvuksi.
SELECT ROUND(avg(length), 0) FROM sakila.film;
-- 13. Ryhmittele elokuvat luokituksen mukaan, jotta saat selville elokuvien määrän eri luokituksissa.
SELECT rating, COUNT(*) FROM sakila.film GROUP BY rating;
-- 14. Tee edellinen haku uudelleen mutta näytä tulokset pienimmästä suurimpaan.
SELECT rating, COUNT(*) FROM sakila.film GROUP BY rating ORDER BY COUNT(*) ASC;
-- 15. Etsi niiden asiakkaiden tiedot, joiden etunimi alkaa "carol".
SELECT * FROM sakila.customer WHERE first_name LIKE "carol%";
-- 16. Tee edellinen haku uudelleen mutta yhdistä tuloksessa asiakkaan etunimi ja sukunimi yhdeksi sarakkeeksi "nimi".
SELECT concat(first_name, " ", last_name) AS nimi, customer_id, store_id, email, address_id, active, create_date, last_update FROM sakila.customer WHERE first_name LIKE "carol%";
-- 17. Etsi niiden asiakkaiden tiedot, joiden sähköpostissa esiintyy merkit "martin".
SELECT * FROM sakila.customer WHERE email LIKE "%martin%";
-- 18. Etsi niiden elokuvien määrä, joiden kuvauksessa esiintyy sana "amazing".
SELECT * FROM sakila.film WHERE description LIKE "%amazing%";
-- 1H. Selvitä asiakkaan, jonka tunniste on 85, kokonimi, sähköposti ja hänen osoitetiedoissaan oleva kadunnimi.
SELECT concat(first_name, " ",last_name) AS kokonimi, email, (SELECT address FROM sakila.address WHERE address_id = 89) AS Osoite FROM sakila.customer WHERE customer_id = 85;
-- 2H. Tee edellinen haku uudelleen mutta lisää vielä tulokseen mukaan asiakkaan postinumero, kaupunki ja maa.
SELECT concat(first_name, " ",last_name) AS kokonimi, email, address.postal_code, city.city, country.country FROM sakila.customer INNER JOIN sakila.city INNER JOIN sakila.country INNER JOIN sakila.address ON(customer.customer_id = address.address_id AND address.city_id = city.city_id AND city.country_id = country.country_id) WHERE customer_id = 85;
-- 3H. Muuta edellisen haun ehtoja. Tarkenna hakua ja etsi kaikki ne asiakkaat, joiden maa on Saksa (germany).
SELECT concat(first_name, " ",last_name) AS kokonimi, email, address.postal_code, city.city, country.country FROM sakila.customer INNER JOIN sakila.city INNER JOIN sakila.country INNER JOIN sakila.address ON(customer.customer_id = address.address_id AND address.city_id = city.city_id AND city.country_id = country.country_id) WHERE country.country LIKE "Germany";