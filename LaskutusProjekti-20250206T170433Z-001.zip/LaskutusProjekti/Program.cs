﻿// See https://aka.ms/new-console-template for more information


using LaskutusProjekti;

HaluatkoKirjautua haluatko = new HaluatkoKirjautua();

AsiakasNakyma nakyma_a = new AsiakasNakyma();

YritysNakyma nakyma_y = new YritysNakyma();

