﻿// See https://aka.ms/new-console-template for more information

namespace LaskutusProjekti
{


    class YritysNakyma : RegisterLogin
    {
        public YritysNakyma()
        {
            Subsciption subscription = new Subsciption();
            Free_Trial free_Trial = new Free_Trial();
            Basic basic = new Basic();
            Pro pro = new Pro();
            Enterprise enterprise = new Enterprise();


            Console.WriteLine("Hei, valitse seuraavista vaihtoehdoista: ");

            Console.WriteLine("[1] Katso tulevat maksut");
            Console.WriteLine("[2] Tee tilaus");

            var valinta = int.Parse(Console.ReadLine());

            //valinta katso tulevat maksut
            if (valinta == 1)
            {
                //go to tulevat maksut sivulle
            }


            //valinta tee tilaus
            if (valinta == 2)
            {
                Console.WriteLine("[1] 30 päivän ilmainen kokeilujakso");
                Console.WriteLine("[2] Basic");
                Console.WriteLine("[3] Pro");
                Console.WriteLine("[4] Enterprise");

                var tilaus_valinta = int.Parse(Console.ReadLine());

                //valinta ilmainen kokeilujakso
                if (tilaus_valinta == 1)
                {
                    Console.WriteLine(free_Trial.Advertisement);
                    Console.WriteLine($"Ja se täysin ilmainen");
                    Console.WriteLine("Haluatko tehdä tilauksen?");
                    Console.WriteLine("[1] Kyllä");
                    Console.WriteLine("[2] Palaa edelliseen valikkoon");
                    var free_valinta = int.Parse(Console.ReadLine());
                    if (free_valinta == 2)
                    {
                        Console.WriteLine("Hei (asiakkaan nimi) Valitse seuraavista vaihtoehdoista: ");
                        //Tämä pitää saada vielä, jotenkin looppaamaan takaisin tuonne alkuun.
                    }
                    else
                    {
                        subscription.SubScribe(enterprise.tyyppi, currentUser_ID);
                    }
                }
                //basic tilaus
                if (tilaus_valinta == 2)
                {
                    Console.WriteLine(basic.Advertisement);
                    Console.WriteLine($"Ja se maksaa vain {basic.Price}€");
                    Console.WriteLine("Haluatko tehdä tilauksen?");
                    Console.WriteLine("[1] Kyllä");
                    Console.WriteLine("[2] Palaa edelliseen valikkoon");
                    var basic_valinta = int.Parse(Console.ReadLine());
                    if (basic_valinta == 2)
                    {
                        Console.WriteLine("Hei (asiakkaan nimi) Valitse seuraavista vaihtoehdoista: ");
                        //Tämä pitää saada vielä, jotenkin looppaamaan takaisin tuonne alkuun.
                    }
                    else
                    {
                        subscription.SubScribe(enterprise.tyyppi, currentUser_ID);
                    }
                }
                //pro tialaus
                if (tilaus_valinta == 3)
                {
                    Console.WriteLine(pro.Advertisement);
                    Console.WriteLine($"Ja se maksaa vain {pro.Price}€");
                    Console.WriteLine("Haluatko tehdä tilauksen?");
                    Console.WriteLine("[1] Kyllä");
                    Console.WriteLine("[2] Palaa edelliseen valikkoon");
                    var pro_valinta = int.Parse(Console.ReadLine());
                    if (pro_valinta == 2)
                    {
                        Console.WriteLine("Hei (asiakkaan nimi) Valitse seuraavista vaihtoehdoista: ");
                        //Tämä pitää saada vielä, jotenkin looppaamaan takaisin tuonne alkuun.
                    }
                    else
                    {
                        subscription.SubScribe(enterprise.tyyppi, currentUser_ID);
                    }
                }

                //enterprise tilaus
                if (tilaus_valinta == 4)
                {
                    Console.WriteLine(enterprise.Advertisement);
                    Console.WriteLine($"Ja se maksaa vain {enterprise.Price}€");
                    Console.WriteLine("Haluatko tehdä tilauksen?");
                    Console.WriteLine("[1] Kyllä");
                    Console.WriteLine("[2] Palaa edelliseen valikkoon");
                    var enterprise_valinta = int.Parse(Console.ReadLine());
                    if (enterprise_valinta == 2)
                    {
                        Console.WriteLine("Hei (asiakkaan nimi) Valitse seuraavista vaihtoehdoista: ");
                        //Tämä pitää saada vielä, jotenkin looppaamaan takaisin tuonne alkuun.
                    }
                    else
                    {
                        subscription.SubScribe(enterprise.tyyppi, currentUser_ID);
                    }
                }

            }
        }
    }
}