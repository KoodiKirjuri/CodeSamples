﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaskutusProjekti
{
    internal class Subsciption
    {
        Free_Trial free_Trial = new Free_Trial();
        Basic basic = new Basic();
        Pro pro = new Pro();
        Enterprise enterprise = new Enterprise();
        public void SubScribe(string tyyppi, int Customer_ID)
        {
            if (tyyppi == "free_trial")
            {
                var input = AskCreditCard();
                if (CheckCreditCard(input) == true)
                {
                    using (StreamReader sr = new StreamReader("Accounts.txt", true))
                    {
                        var Line = sr.ReadLine();
                        if (Line == "ID: " + Customer_ID)
                        {
                            using (StreamWriter sw = new StreamWriter("Accounts.txt", true))
                            {
                                sw.WriteLine("Acesslevel: " + free_Trial.Access_Level);
                                sw.Close();
                            }
                        }
                        sr.Close();
                    }
                }
            }
            else if (tyyppi == "basic")
            {
                var input = AskCreditCard();
                if (CheckCreditCard(input) == true)
                {
                    using (StreamWriter sw = new StreamWriter("Accounts.txt", true))
                    {
                        sw.WriteLine("Acesslevel: " + basic.Access_Level);
                        sw.Close();
                    }
                }
            }
            else if (tyyppi == "pro")
            {
                var input = AskCreditCard();
                if (CheckCreditCard(input) == true)
                {
                    using (StreamWriter sw = new StreamWriter("Accounts.txt", true))
                    {
                        sw.WriteLine("Acesslevel: " + pro.Access_Level);
                        sw.Close();
                    }
                }
            }
            else if (tyyppi == "enterprise")
            {
                var input = AskCreditCard();
                if (CheckCreditCard(input) == true)
                {
                    using (StreamWriter sw = new StreamWriter("Accounts.txt", true))
                    {
                        sw.WriteLine("Acesslevel: " + enterprise.Access_Level);
                        sw.Close();
                    }
                }
            }
            else
            {
                Console.WriteLine("Nyt meni kyllä jotain vikaan");
            }

        }
        private static string AskCreditCard()
        {
            Console.WriteLine("Anna luottokortin numero: ");
            string input = Console.ReadLine();
            while (CheckCreditCard(input) == false)
            {
                Console.WriteLine("Meni jokin vikaan. Kirjoita luottokortin numero uudelleen: ");
                Console.WriteLine("Jos haluat lopettaa, kirjoita 2");
                input = Console.ReadLine();
                if (input == "2")
                {
                    break;
                }
            }
            return input;
        }
        private static bool CheckCreditCard(string input)
        {
            if (input.Length == 16)
            {
                return true;
            }
            else
            {
                Console.WriteLine("Meni jotain vikaan");
                return false;
            }
        }

        public int Billing(string Subsciption_Type, DateOnly First_date)
        {
            return 30;
        }
        public void Unsubscribe(int id)
        {
            using (StreamReader sr = new StreamReader("Accounts.txt", true))
            {
                while (true)
                {
                    string line = sr.ReadLine();
                    if (line == "ID: " + id)
                    {
                        while (line.Split(":")[0] != "Access_Level")
                        {
                            using (StreamWriter sw = new StreamWriter("Accounts.txt", true))
                            {
                                sw.WriteLine("");
                                sw.Close();
                            }
                        }
                    }
                }
                sr.Close();
            }
        }
    }
}
