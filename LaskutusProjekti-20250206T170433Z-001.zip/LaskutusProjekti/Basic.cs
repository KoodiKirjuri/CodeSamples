﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaskutusProjekti
{
    internal class Basic
    {
        public string tyyppi = "basic";
        public string Access_Level = "Sinulla on käyttöoikeus viiteen työkaluun ja voit luoda yhden tilin.";
        public int Price = 10;
        public string Advertisement = "Sinulla olisi käyttöoikeus viiteen työkaluun ja voisit luoda yhden tilin.";
    }
}
