﻿// See https://aka.ms/new-console-template for more informatio
class incoming1_0
{
    incoming1_0()
    {
        Console.WriteLine("Mitä tasoa etsit?");

        Console.WriteLine("Basic?");
        Console.WriteLine("Pro?");
        Console.WriteLine("Enterprice?");
        //Jos kirjoittaa esim. Basic => Laskee Basic * Basic
        var input = Console.ReadLine();


        //Laskee Basic:in hinnan
        if (input == "Basic")
        {
            incoming Basic = new incoming();
            Basic.Nimi = "Basic";
            Basic.Hinta = 10;
            Console.WriteLine(Basic.Hinta * Basic.Hinta);
            Console.WriteLine("Rahamäärä: " + Basic.Hinta * Basic.Hinta);

        }
        //laskee Pro:n hinnan
        if (input == "Pro")
        {
            incoming Pro = new incoming();
            Pro.Nimi = "Pro";
            Pro.Hinta = 15;
            Console.WriteLine(Pro.Hinta * Pro.Hinta);
            Console.WriteLine("Rahamäärä: " + Pro.Hinta * Pro.Hinta);

        }
        //laskee enterprice hinnan
        if (input == "Enterprice")
        {
            incoming Enterprice = new incoming();
            Enterprice.Nimi = "Enterprice";
            Enterprice.Hinta = 20;
            Console.WriteLine("Rahamäärä: " + Enterprice.Hinta * Enterprice.Hinta);

        }
        //Incoming class
    }
}

public class incoming
{
    public string? Nimi { get; set; }
    public int Hinta { get; set; }

}
