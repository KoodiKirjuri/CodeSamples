﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LaskutusProjekti
{
    internal class Kalenteri
    {
        //kirjasto kuukausista ja niiden päivien määristä
        public static Dictionary<int, int> paivatkk = new Dictionary<int, int>()
        {
            {1,31}, {2,28}, {3,31}, {4,30},
            {5,31}, {6,30}, {7,31}, {8,31},
            {9,30}, {10,31}, {11,30}, {12,31}
        };
                
        internal class Paivays
        {
            public int paiva;
            public int kuukausi;
            public int vuosi;

            public Paivays(int paiva, int kuukausi, int vuosi)
            {
                this.paiva = paiva;
                this.kuukausi = kuukausi;
                this.vuosi = vuosi;
            }
        }
        //Laskee kuukauden eteenpäin
        public static Paivays KuukausiJalkeen(Paivays paivays)
        {
            int paivat = paivatkk[paivays.kuukausi];
            int temp = paivays.paiva; 
            if(temp + 30 > paivat)
            {
                paivays.kuukausi++;
                if(paivays.paiva <= 0)
                {
                    paivays.paiva = 1;
                }

                if(paivays.kuukausi > 12)
                {
                    paivays.vuosi++;
                    paivays.kuukausi = 1; 
                }
            }
            else
            {
                paivays.paiva += 30;
            }
            return paivays;
        }
    }
}