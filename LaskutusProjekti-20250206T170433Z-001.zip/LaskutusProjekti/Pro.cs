﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaskutusProjekti
{
    internal class Pro
    {
        public string tyyppi = "pro";
        public string Access_Level = "Siunlla on käyttöoikeus kymmeneen työkaluun ja voit luoda viisi tiliä.";
        public int Price = 15;
        public string Advertisement = "Sinulla olisi käyttöoikeus kymmeneen työkaluun ja voisit luoda viisi tiliä.";
    }
}
