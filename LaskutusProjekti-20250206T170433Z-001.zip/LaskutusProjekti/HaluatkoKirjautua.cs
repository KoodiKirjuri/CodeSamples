﻿// See https://aka.ms/new-console-template for more information
namespace LaskutusProjekti
{

    class HaluatkoKirjautua
    {
        public HaluatkoKirjautua()
        {
            Console.WriteLine("Haluatko kirjautua sisään? (1 Kirjaudu sisään / 2 Peruuta)");
            var input = Console.ReadLine();
            
            // Avaa kirjautumis sivun
            if (input == "1")
            {
                return;
            }

            // Sulkee ohjelman
            else if (input == "2")
            {
                Environment.Exit(0);
            }
        }
    }
}
