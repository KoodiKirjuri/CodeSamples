﻿// See https://aka.ms/new-console-template for more information
namespace LaskutusProjekti
{
    class AsiakasNakyma : RegisterLogin
    {
        public AsiakasNakyma()
        {
            //Näitä tarvitaan kun luo noita if lauseita
            Subsciption subscription = new Subsciption();
            Free_Trial free_Trial = new Free_Trial();
            Basic basic = new Basic();
            Pro pro = new Pro();
            Enterprise enterprise = new Enterprise();


            Start:
            Console.WriteLine("Valitse seuraavista vaihtoehdoista: ");

            Console.WriteLine("[1] Tee uusi tilaus");
            Console.WriteLine("[2] Vaihda olemassa olevan tilauksen tyyppiä");
            Console.WriteLine("[3] Peruuta olemassa oleva tilaus");
            Console.WriteLine("[4] Sulje sovellus");

            var toiminta_valinta = int.Parse(Console.ReadLine());

            if (toiminta_valinta == 1)
            {
                Console.WriteLine("Valitse seuraavista vaihtoehdoista: ");

                Console.WriteLine("[1] 30 päivän ilmainen kokeilujakso");
                Console.WriteLine("[2] Basic");
                Console.WriteLine("[3] Pro");
                Console.WriteLine("[4] Enterprise");
                Console.WriteLine("[5] Palaa takaisin päävalikkoon");

                var tilaus_valinta = int.Parse(Console.ReadLine());

                //ilmainen kokeilujakso
                if (tilaus_valinta == 1)
                {
                    Console.WriteLine(free_Trial.Advertisement);
                    Console.WriteLine($"Ja se on täysin ilmainen.");
                    Console.WriteLine("Haluatko tehdä tilauksen?");
                    Console.WriteLine("[1] Kyllä");
                    Console.WriteLine("[2] Palaa päävalikkoon");
                    var free_valinta = int.Parse(Console.ReadLine());
                    if (free_valinta == 2)
                    {
                        goto Start;
                    }
                    else
                    {
                        subscription.SubScribe(free_Trial.tyyppi, currentUser_ID);
                    }

                }

                //basic tilaus
                if (tilaus_valinta == 2)
                {
                    Console.WriteLine(basic.Advertisement);
                    Console.WriteLine($"Ja se maksaa vain {basic.Price}€");
                    Console.WriteLine("Haluatko tehdä tilauksen?");
                    Console.WriteLine("[1] Kyllä");
                    Console.WriteLine("[2] Palaa päävalikkoon");
                    var basic_valinta = int.Parse(Console.ReadLine());
                    if (basic_valinta == 2)
                    {
                        goto Start;
                    }
                    else
                    {
                        subscription.SubScribe(basic.tyyppi, currentUser_ID);
                    }

                }

                // pro tilaus
                if (tilaus_valinta == 3)
                {
                    Console.WriteLine(pro.Advertisement);
                    Console.WriteLine($"Ja se maksaa vain {pro.Price}€");
                    Console.WriteLine("Haluatko tehdä tilauksen?");
                    Console.WriteLine("[1] Kyllä");
                    Console.WriteLine("[2] Palaa päävalikkoon");
                    var pro_valinta = int.Parse(Console.ReadLine());
                    if (pro_valinta == 2)
                    {
                        goto Start;
                    }
                    else
                    {
                        subscription.SubScribe(pro.tyyppi, currentUser_ID);
                    }
                }

                //enterprise tilaus
                if (tilaus_valinta == 4)
                {
                    Console.WriteLine(enterprise.Advertisement);
                    Console.WriteLine($"Ja se maksaa vain {enterprise.Price}€");
                    Console.WriteLine("Haluatko tehdä tilauksen?");
                    Console.WriteLine("[1] Kyllä");
                    Console.WriteLine("[2] Palaa päävalikkoon");
                    var enterprise_valinta = int.Parse(Console.ReadLine());
                    if (enterprise_valinta == 2)
                    {
                        goto Start;
                    }
                    else
                    {
                        subscription.SubScribe(enterprise.tyyppi, currentUser_ID);
                    }
                }

                if (tilaus_valinta == 5)
                {
                    goto Start;
                }

                else
                {
                    Console.WriteLine("Nyt tapatui jokin virhe. Palataan alkuun");
                    goto Start;
                }
            }

            //vaihda tilaus valinta
            if (toiminta_valinta == 2)
            {
                Console.WriteLine("Haluatko varmasti muuttaa tilausta? ");
                Console.WriteLine("[1] Kyllä");
                Console.WriteLine("[2] En, palaa takaisin päävalikkoon");

                var muutos_valinta = int.Parse(Console.ReadLine());

                if (muutos_valinta == 1)
                {
                    //go to sivulle jolla pystyy vaihtamaan tilauksen tyypin
                }
                if (muutos_valinta == 2)
                {
                    goto Start;
                }
               
            }

            //peruuta tilaus valinta
            if (toiminta_valinta == 3)
            {
                Console.WriteLine("Haluatko varmasti peruuttaa tilausen? ");
                Console.WriteLine("[1] Kyllä");
                Console.WriteLine("[2] En, palaa takaisin päävalikkoon");

                var peruuta_valinta = int.Parse(Console.ReadLine());

                if (peruuta_valinta == 1)
                {
                    subscription.Unsubscribe(currentUser_ID);
                }
                if (peruuta_valinta == 2)
                {
                    goto Start;
                }   
            }
            else { Environment.Exit(0); }
        }
    }
}