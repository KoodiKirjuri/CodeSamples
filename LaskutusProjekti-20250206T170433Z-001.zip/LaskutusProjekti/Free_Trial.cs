﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaskutusProjekti
{
    internal class Free_Trial
    {
        public string tyyppi = "free_trial";
        public string Access_Level = "Sinulla on käyttöoikeudet viiteen työkaluun ja voit luoda yhden tilin.";
        public int Price = 0;
        public string Advertisement = "Sinulla olisi käyttöoikeudet viiteen työkaluun ja voisit tehdä yhden tilin 30 päiväksi.";
        public void Expiration_date(System.DateTime today)
        {
            /*if (Current_day >= today + 30)
            {
                Unsubscirbe();
            }*/
        }
    }
}
