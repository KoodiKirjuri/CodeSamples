﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaskutusProjekti
{
    internal class Enterprise
    {
        public string tyyppi = "enterprise";
        public string Access_Level = "Sinulla on käyttöoikeus kaikkiin työkaluihin ja voit luoda rajattomasti tilejä.";
        public int Price = 20;
        public string Advertisement = "Sinulla olisi käyttöoikeus kaikkiin työkaluihin ja voisit luoda rajattomasti tilejä.";
    }
}
