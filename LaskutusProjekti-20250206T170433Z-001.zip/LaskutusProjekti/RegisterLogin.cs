﻿// See https://aka.ms/new-console-template for more information

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

namespace LaskutusProjekti

{
    internal class RegisterLogin
    {
        public int currentUser_ID { get; set; }
        public RegisterLogin()
        {
            var arrUsers = new Users[]
             {

             };

        Start:
            Console.WriteLine("Kirjaudu tai rekisteröidy (1= Kirjaudu/2= Rekisteröidy)");
            var input = Console.ReadLine();

            bool successfull = false;
            while (!successfull)
            {

                if (input == "1")
                {
                    Console.WriteLine("Syötä käyttäjätunnus:");
                    var username = Console.ReadLine();
                    Console.WriteLine("Syötä salasana:");
                    var password = Console.ReadLine();
                    foreach (Users user in arrUsers)
                    {
                        if (username == user.username && password == user.password)
                        {
                            successfull = true;
                            Console.WriteLine("Kirjautuminen onnistui !");
                            currentUser_ID = user.id;
                        }
                    }

                    if (!successfull)
                    {
                        Console.WriteLine("Käyttäjätunnus tai salasana on väärin, yritä uudelleen tai rekisteröi uusi käyttäjä !");
                        goto Start;
                    }

                }

                else if (input == "2")
                {

                    Console.WriteLine("Syötä etunimi: ");
                    var firstName = Console.ReadLine();

                    Console.WriteLine("Syötä sukunimi: ");
                    var lastName = Console.ReadLine();

                    Console.WriteLine("Syötä sähköpostiosoite: ");
                    var email = Console.ReadLine();

                    Console.WriteLine("Luo käyttäjätunnus: ");
                    var username = Console.ReadLine();

                    Console.WriteLine("Luo salasana: ");
                    var password = Console.ReadLine();

                    Console.WriteLine("Luodaan yksilöllinen ID tunnus... ");
                    Random rnd = new Random();
                    int id = rnd.Next(1, 999999);
                    Console.WriteLine("Sinun yksilöllinen ID tunnus on: " + id);

                    using (StreamWriter sw = new StreamWriter("Accounts.txt", true))
                    {
                        sw.WriteLine("Käyttäjätunnus: " + username);
                        sw.WriteLine("Salasana: " + password);
                        sw.WriteLine("ID: " + id);
                        sw.WriteLine("Etunimi: " + firstName);
                        sw.WriteLine("Sukunimi: " + lastName);
                        sw.WriteLine("Sähköposti: " + email);
                        sw.Close();
                    }






                    Array.Resize(ref arrUsers, arrUsers.Length + 1);
                    arrUsers[arrUsers.Length - 1] = new Users(username, password);
                    successfull = true;
                    goto Start;




                }
                else
                {
                    Console.WriteLine("Virheellinen valinta, käytä (1/2) vaihtoehtoja. Yritä uudelleen !");
                    break;
                }

            }

        }
    }
    public class Users
    {
        public string username;
        public string password;
        public int id;

        public Users(string? username, string? password)
        {
            this.username = username;
            this.password = password;
        }

        public Users(string username, string password, int id)
        {
            this.username = username;
            this.password = password;
            this.id = id;
        }
    }

}