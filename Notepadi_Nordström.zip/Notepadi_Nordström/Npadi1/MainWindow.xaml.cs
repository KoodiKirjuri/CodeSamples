﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Npadi1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        // exit
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void menuOpen_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog();
            // voit asettaa ikkunan tietoja
            dialog.ShowDialog();
            if (dialog.ShowDialog() == true)
                textBox.Text = File.ReadAllText(dialog.FileName);
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Window1();
            dialog.ShowDialog();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            printDialog.ShowDialog();
            printDialog.PrintVisual(textBox, "textbox");
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.SaveFileDialog();
            dialog.FileName = "Document";
            dialog.DefaultExt = ".text";
            dialog.Filter = "Text documents (.txt)|*.txt";
            Nullable<bool> result = dialog.ShowDialog();
            if (result == true)
            {
                File.WriteAllText(dialog.FileName, textBox.Text);
            }
        }
    }
}
