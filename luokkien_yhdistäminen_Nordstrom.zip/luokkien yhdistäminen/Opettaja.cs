﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace luokkien_yhdistäminen
{
    public class Opettaja
    {
        public string OpeNimi { get; set; }
        
        public virtual void Tulosta()
        {
            Console.WriteLine(OpeNimi);
        }
        
    }
    public class Moduuli : Opettaja
    {
        public string ModuuliNimi { get; set; }

        public List<Opettajat> OpeLista = new();
        public void LisaaOpettaja(string OpeNimi)
        {
            var OpenNimi = new Opettajat(OpeNimi);
            OpeLista.Add(OpenNimi);
        }
        public override void Tulosta()
        {
            Console.WriteLine(ModuuliNimi);
        }
    }

    public class Oppilas : Moduuli
    {
        public string OppilaanNimi { get; set; }

        public List<Moduulit> ModuuliLista = new();
        public void LisaaModuuli(string ModuuliNimi)
        {
            var Moduli = new Moduulit(ModuuliNimi);
            ModuuliLista.Add(Moduli);
        }

        public override void Tulosta()
        {
            Console.Write(OppilaanNimi);
        }
    }
    public record Opettajat(string OpeNimi);
    public record Moduulit(string ModuuliNimi);
}