﻿using luokkien_yhdistäminen;

Opettaja Opettaja1 = new Opettaja();
Moduuli Moduuli1 = new Moduuli();
Oppilas Oppilas1 = new Oppilas();
Opettaja Opettaja2 = new Opettaja();
Moduuli Moduuli2 = new Moduuli();
Oppilas Oppilas2 = new Oppilas();
Opettaja Opettaja3 = new Opettaja();

Opettaja1.OpeNimi = "Oiva pasma";
Opettaja2.OpeNimi = "Kaisa Friman";
Opettaja3.OpeNimi = "Virve hasa";
Opettaja1.Tulosta();
Opettaja2.Tulosta();
Opettaja3.Tulosta();

Moduuli1.ModuuliNimi = "Web-tekniikka";
Moduuli2.ModuuliNimi = "Ohjelmointi";
Moduuli1.LisaaOpettaja(Opettaja1.OpeNimi);
Moduuli1.LisaaOpettaja(Opettaja3.OpeNimi);
Moduuli2.LisaaOpettaja(Opettaja2.OpeNimi);
Moduuli2.LisaaOpettaja(Opettaja3.OpeNimi);
Moduuli1.Tulosta();
Moduuli2.Tulosta();

Oppilas1.OppilaanNimi = "Raimo";
Oppilas2.OppilaanNimi = "Markku";
Oppilas1.LisaaModuuli(Moduuli1.ModuuliNimi);
Oppilas2.LisaaModuuli(Moduuli1.ModuuliNimi);
Oppilas2.LisaaModuuli(Moduuli2.ModuuliNimi);
Oppilas1.Tulosta();
Console.WriteLine();
Oppilas2.Tulosta();
Console.WriteLine();
Console.WriteLine($"Oppilaalla {Oppilas1.OppilaanNimi} on Moduulit {Moduuli1.ModuuliNimi} Ja tässä moduulissa opettaa {Opettaja1.OpeNimi} ja {Opettaja3.OpeNimi}");
Console.WriteLine($"Oppilaalla {Oppilas2.OppilaanNimi} on Moduulit {Moduuli1.ModuuliNimi} Ja {Moduuli2.ModuuliNimi}, näissä moduuleissa opettaa {Opettaja1.OpeNimi}, {Opettaja3.OpeNimi}, {Opettaja2.OpeNimi} ja {Opettaja3.OpeNimi}");

Console.ReadLine();
